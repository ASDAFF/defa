<?
	$MESS["SERVICE_MAIN_SETTINGS"] = "Настройки сайта";
	$MESS["SERVICE_IBLOCK"] = "Информационные блоки";
	$MESS["SERVICE_SALE_DEMO_DATA"] = "Настройка интернет-магазина";
	$MESS["SERVICE_IBLOCK_DEMO_DATA"] = "Добавление каталогов (может потребоваться продолжительное время)";
	$MESS["SERVICE_FORM_DEMO_DATA"] = "Добавление форм";
	$MESS["SERVICE_BLOG_DEMO_DATA"] = "Настройка блога идей";
	$MESS["SERVICE_CATALOG_SETTINGS"] = "Настройка каталога";
	$MESS["SERVICE_FORUM"] = "Настройка форума для отзывов";
?>