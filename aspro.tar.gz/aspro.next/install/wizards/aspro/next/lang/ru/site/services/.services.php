<?
$MESS["SERVICE_MAIN_SETTINGS"] = "Копирование файлов и настройка сайта";
$MESS["SERVICE_SEARCH"] = "Переиндексация сайта";
$MESS["SERVICE_IBLOCK_DEMO_DATA"] = "Создание каталогов";
$MESS["SERVICE_IBLOCK"] = "Информационные блоки";
$MESS["SERVICE_FORM_DEMO_DATA"] = "Добавление форм";
$MESS["SERVICE_SALE_DEMO_DATA"] = "Настройка интернет-магазина";
$MESS["SERVICE_BLOG_DEMO_DATA"] = "Настройка блога идей";
$MESS["SERVICE_FORUM"] = "Настройка форума для отзывов";
$MESS["SERVICE_CATALOG_SETTINGS"] = "Настройка каталога";
?>