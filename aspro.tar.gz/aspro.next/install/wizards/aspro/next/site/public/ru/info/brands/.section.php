<?
$sSectionName = "Производители";
$arDirProperties = Array(

);
?>