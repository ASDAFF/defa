<?
$sSectionName = "Иконки";
$arDirProperties = Array(

);
?>