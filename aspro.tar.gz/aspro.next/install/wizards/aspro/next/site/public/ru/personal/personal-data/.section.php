<?
$sSectionName = "Персональные данные";
$arDirProperties = Array(
   "lmenu" => "да"
);
?>