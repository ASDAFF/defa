<?include($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");?>
<div class="include_module_error">
	<img src="<?=SITE_TEMPLATE_PATH?>/images/error.jpg" title=":-(">
	<p>Ошибка проверки ключа решения &laquo;Аспро: Next - интернет-магазин&raquo;.<br />Вы используете нелегальную версию продукта, пожалуйста обратитесь к партнеру, предоставившему решение</p>
</div>
