<?
$sSectionName = "Вопрос-ответ";
$arDirProperties = Array(

);
?>