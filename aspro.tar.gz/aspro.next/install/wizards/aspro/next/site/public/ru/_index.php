<?
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");
$APPLICATION->SetPageProperty("viewed_show", "Y");
$APPLICATION->SetTitle("#SITE_NAME#");
?>

<?require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php");?>