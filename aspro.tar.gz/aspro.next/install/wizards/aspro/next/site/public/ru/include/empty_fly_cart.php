<div class="title">Ваша корзина пуста</div>
 
<p>Исправить это просто: выберите в каталоге интересующий товар и нажмите кнопку &laquo;В корзину&raquo;. </p><br />

<a class="btn btn-default" href="<?=CNext::GetFrontParametrValue("CATALOG_PAGE_URL");?>"><span>В каталог</span></a>