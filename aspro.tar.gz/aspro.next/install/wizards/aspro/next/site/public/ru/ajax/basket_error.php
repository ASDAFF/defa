<a href="#" class="close jqmClose"><i></i></a>
<div class="popup-intro">
	<div class="pop-up-title">Ошибка корзины</div>
</div>
<div class="form-wr">
	<div class="ajax_text" id="bx_ajax_text"></div>
</div>
