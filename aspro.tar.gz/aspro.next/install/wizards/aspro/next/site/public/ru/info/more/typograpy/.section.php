<?
$sSectionName = "Оформление";
$arDirProperties = Array(

);
?>