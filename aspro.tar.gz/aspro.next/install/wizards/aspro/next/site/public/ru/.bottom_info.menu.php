<?
$aMenuLinks = Array(
	Array(
		"Информация", 
		"#SITE_DIR#info/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Помощь", 
		"#SITE_DIR#help/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Условия оплаты", 
		"#SITE_DIR#help/payment/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Условия доставки", 
		"#SITE_DIR#help/delivery/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Гарантия на товар", 
		"#SITE_DIR#help/warranty/", 
		Array(), 
		Array(), 
		"" 
	),
	Array(
		"Возможности", 
		"#SITE_DIR#info/more/", 
		Array(), 
		Array(), 
		"" 
	)
);
?>