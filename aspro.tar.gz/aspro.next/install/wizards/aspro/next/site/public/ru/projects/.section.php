<?
$sSectionName = "Проекты";
$arDirProperties = Array(
   "MENU" => "N",
   "MENU_SHOW_ELEMENTS" => "N",
   "MENU_SHOW_SECTIONS" => "Y",
   "HIDE_LEFT_BLOCK" => "Y",
);
?>