<?
$sSectionName = "Лицензии и сертификаты";
$arDirProperties = Array(

);
?>