<script src="//yastatic.net/es5-shims/0.0.2/es5-shims.min.js"></script> <script src="//yastatic.net/share2/share.js" charset="UTF8"></script>
<div class="share_wrapp">
	<div class="text btn transparent">
		<?=GetMessage("SHARE_BUTTON");?>
	</div>
	<div class="ya-share2 yashare-auto-init shares" data-services="vkontakte,facebook,odnoklassniki,moimir,twitter,viber,whatsapp,skype,telegram">
	</div>
</div>
<br>