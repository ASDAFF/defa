<?
$sSectionName = "Условия оплаты";
$arDirProperties = Array(

);
?>