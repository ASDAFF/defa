<div class="include_module_error">
	<img src="<?=SITE_TEMPLATE_PATH?>/images/error.jpg" title=":-(">
	<p>Ошибка подключения модуля &laquo;Аспро: Next - интернет-магазин&raquo;.<br />Пожалуйста <a href="/bitrix/admin/partner_modules.php?lang=ru">установите модуль</a> и повторите попытку</p>
</div>
