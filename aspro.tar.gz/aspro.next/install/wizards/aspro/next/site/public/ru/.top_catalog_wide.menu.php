<?
$aMenuLinks = Array(
	Array(
		"Акции", 
		"/sale/", 
		Array(), 
		Array("CLASS" => "icon sale_icon"), 
		"" 
	)
);
?>