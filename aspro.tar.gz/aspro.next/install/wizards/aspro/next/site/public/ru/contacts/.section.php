<?
$sSectionName = "Контакты";
$arDirProperties = array(
   "HIDE_LEFT_BLOCK" => "Y",
   "WIDE_PAGE" => "Y",
   "HIDETITLE" => "Y"
);
?>