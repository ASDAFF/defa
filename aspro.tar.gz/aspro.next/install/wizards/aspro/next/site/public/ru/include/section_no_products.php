<span class="big_text">К сожалению, раздел пуст</span><br>
 <span class="middle_text">В данный момент нет активных товаров</span>