<?
$sSectionName = "Услуги";
$arDirProperties = Array(
   "MENU" => "Y",
   "MENU_SHOW_ELEMENTS" => "Y",
   "MENU_SHOW_SECTIONS" => "N"
);
?>