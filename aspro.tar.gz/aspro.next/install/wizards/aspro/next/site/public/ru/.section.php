<?
$sSectionName = "Главная";
$arDirProperties = Array(
   "description" => "#SITE_DESCRIPTION#",
   "keywords" => "#SITE_KEYWORDS#"
);
?>