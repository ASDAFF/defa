<?
$sSectionName = "Поиск";
$arDirProperties = array(
   "HIDE_LEFT_BLOCK" => "Y"
);
?>