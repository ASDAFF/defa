<?
$sSectionName = "Авторизация";
$arDirProperties = Array(
	"HIDE_LEFT_BLOCK" => "Y"
);
?>