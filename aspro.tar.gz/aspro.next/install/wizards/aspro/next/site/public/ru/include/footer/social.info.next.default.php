<?$APPLICATION->IncludeComponent(
	"aspro:social.info.next", 
	".default", 
	array(
		"CACHE_TYPE" => "A",
		"CACHE_TIME" => "3600000",
		"CACHE_GROUPS" => "N",
		"TITLE_BLOCK" => "Мы в социальных сетях:",
		"COMPONENT_TEMPLATE" => ".default",
	),
	false
);?> 