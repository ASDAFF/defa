<?
$sSectionName = "Заполнение формы";
$arDirProperties = array(
   "MENU" => "N",
   "HIDE_LEFT_BLOCK" => "Y",
);
?>