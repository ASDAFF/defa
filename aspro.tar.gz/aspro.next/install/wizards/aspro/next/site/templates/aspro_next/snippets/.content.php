<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
$SNIPPETS = array(
	'custom/snippet0001.snp' => array('title' => 'Quote with font-size:medium', 'description' => 'Add quote block'),
	'custom/snippet0002.snp' => array('title' => 'Quote', 'description' => 'Add quote block'),
	'custom/snippet0003.snp' => array('title' => 'Horizontal line'),
	'table/snippet0001.snp' => array('title' => 'Table', 'description' => 'Add table with properties'),
);
?>