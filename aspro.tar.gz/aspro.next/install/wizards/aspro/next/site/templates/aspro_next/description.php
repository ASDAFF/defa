<?
if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();

IncludeTemplateLangFile(__FILE__);

$arTemplate = Array(
	"NAME"=>GetMessage("TEMPLATE_NAME"), 
	"DESCRIPTION"=> GetMessage("TEMPLATE_DESCRIPTION")
);

?>