<?
	$MESS["COPY"] = "Копирайт";
	$MESS["PAYMENT"] = "Оплата";
	$MESS["PHONE"] = "Телефон";
	$MESS["CREATE"] = "Создание сайтов";
	$MESS["NAME"] = "Имя";
	$MESS["OK_MSG"] = "Ваше сообщение успешно отправлено.";
	$MESS["FOUND_CHEAPER"] = "Нашли дешевле?";
	$MESS["ITEM_ADDED"] = "Товар успешно добавлен в корзину";
	$MESS["ITEM_ADDED_ORDER"] = "Перейти к оформлению покупки";
	$MESS["ITEM_ADDED_BACK"] = "Продолжить покупки";
	$MESS["SEND_MSG"] = "Отправить сообщение";
	$MESS["SEND_RESUME"] = "Отправить резюме";
	$MESS["FIO"] = "Фамилияя, Имя, Отчество";
	$MESS["ARBITRARY_1"] = "Произвольная область 1";
	$MESS["ARBITRARY_2"] = "Произвольная область 2";
	$MESS["ROUBLE"] = "руб.";
	$MESS["CALLBACK"] = "Заказать звонок";
?>