<div class="top_inner_block_wrapper maxwidth-theme">
	<div class="page-top-wrapper color vcustom">
		<section class="page-top maxwidth-theme <?CNext::ShowPageProps('TITLE_CLASS');?>">	
			<div class="row">
				<div class="col-md-12">
					<b><?=__FILE__?></b>				
				</div>
			</div>
		</section>
	</div>
</div>