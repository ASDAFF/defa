<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?>
<footer id="footer">
<b><?=__FILE__?></b>
</footer>