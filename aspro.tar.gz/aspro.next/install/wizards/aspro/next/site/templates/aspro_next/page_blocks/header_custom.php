<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();?>
<? global $arTheme;	?>
<header class="header-v4 <?=strtolower($arTheme["ORDER_BASKET_VIEW"]["VALUE"])?> <?=($arTheme["CABINET"]["VALUE"]=='Y'?'cabinet':'')?>">
	<b><?=__FILE__?></b>
</header>