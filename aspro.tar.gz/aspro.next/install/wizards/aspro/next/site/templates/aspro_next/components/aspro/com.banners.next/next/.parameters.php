<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters['CATALOG'] = array(
	'PARENT' => 'BASE',
	'NAME' => GetMessage('CATALOG_TITLE'),
	'TYPE' => 'STRING',
	'DEFAULT' => '/catalog/',
);
?>