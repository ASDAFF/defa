<?
if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();
$arDescription = Array(
		'NAME' => GetMessage('GD_ASPRO_NEXT_NAME'),
		'DESCRIPTION' => GetMessage('GD_ASPRO_NEXT_DESC'),
		'ICON' => '',
		'TITLE_ICON_CLASS' => 'aspro-gadgets-universum',
		'GROUP' => array('ID' => 'other'),
		'NOPARAMS' => 'Y',
		'AI_ONLY' => true,
		'SECURITY_ONLY' => true,
		'COLOURFUL' => true
	);
?>