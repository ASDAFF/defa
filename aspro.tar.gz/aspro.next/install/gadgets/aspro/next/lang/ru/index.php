<?
$MESS['GD_ASPRO_DATE_SUPPORT_TO'] = 'Техническая поддержка доступна до #DATE#';
$MESS['GD_ASPRO_EXPIRED_SOON'] = 'Техническая поддержка заканчивается #DAYS_STR#';
$MESS['GD_ASPRO_EXPIRED'] = 'Для обращения в техническую поддержку требуется продлить лицензию';
$MESS['GD_ASPRO_DESCRIPTION'] = 'Руководство пользователя, база знаний,<br /> FAQ и прямая связь со специалистом';
$MESS['GD_ASPRO_GET_MORE'] = 'Подробнее';
$MESS['GD_ASPRO_BUY'] = 'Купить продление';
$MESS['GD_ASPRO_ERROR'] = 'Не удалось получить информацию об установке решения';
$MESS['GD_ASPRO_THROUGH'] = 'через ';
$MESS['GD_ASPRO_DAYS0'] = 'день';
$MESS['GD_ASPRO_DAYS0_TODAY'] = 'сегодня';
$MESS['GD_ASPRO_DAYS1'] = 'дня';
$MESS['GD_ASPRO_DAYS2'] = 'дней';
?>