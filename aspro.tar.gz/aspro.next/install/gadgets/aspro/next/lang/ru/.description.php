<?
$MESS['GD_ASPRO_NEXT_NAME'] = "Центр управления Aspro: Next - интернет магазин";
$MESS['GD_ASPRO_NEXT_DESC'] = "Центр управления Aspro: Next - интернет магазин";
?>