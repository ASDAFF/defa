<?
$arModuleVersion = array(
	"VERSION" => "1.4.6",
	"VERSION_DATE" => "2019-05-31 00:00:00"
);
?>