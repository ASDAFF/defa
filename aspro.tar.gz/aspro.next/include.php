<?
CModule::AddAutoloadClasses(
	'aspro.next',
	array(
		'CNextCache' => 'classes/general/CNextCache.php',
		'CNext' => 'classes/general/CNext.php',
		'CNextTools' => 'classes/general/CNextTools.php',
		'CNextEvents' => 'classes/general/CNextEvents.php',
		'CNextRegionality' => 'classes/general/CNextRegionality.php',
		'CNextCondition' => 'classes/general/CNextCondition.php',
		'CInstargramNext' => 'classes/general/CInstargramNext.php',
		'Aspro\\Solution\\CAsproMarketing' => 'classes/general/CAsproMarketing.php',
		'Aspro\\Functions\\CAsproSku' => 'lib/functions/CAsproSku.php', //for general sku functions
		'Aspro\\Functions\\CAsproItem' => 'lib/functions/CAsproItem.php', //for general item functions
		'Aspro\\Functions\\CAsproNext' => 'lib/functions/CAsproNext.php', //for only solution functions
		'Aspro\\Functions\\CAsproNextCustom' => 'lib/functions/CAsproNextCustom.php', //for user custom functions
		'Aspro\\Functions\\CAsproNextReCaptcha' => 'lib/functions/CAsproNextReCaptcha.php', //for google reCaptcha
		'Aspro\\Functions\\CAsproNextCRM' => 'lib/functions/CAsproNextCRM.php', //for integrate crm
		'Aspro\\Next\\SearchQuery' => 'lib/searchquery.php', //for landings in search
		'Aspro\\Next\\PhoneAuth' => 'lib/phoneauth.php', //for auth by phone
		// custom user types of properties
		'Aspro\\Next\\Property\\ListStores' => 'lib/property/liststores.php',
		'Aspro\\Next\\Property\\ListPrices' => 'lib/property/listprices.php',
		'Aspro\\Next\\Property\\ListLocations' => 'lib/property/listlocations.php',
		'Aspro\\Next\\Property\\CustomFilter' => 'lib/property/customfilter.php',
		'Aspro\\Next\\Property\\Service' => 'lib/property/service.php',
		'Aspro\\Next\\Property\\YaDirectQuery' => 'lib/property/yadirectquery.php',
		'Aspro\\Next\\Property\\IBInherited' => 'lib/property/ibinherited.php',
	)
);

/* test events */

/*AddEventHandler('aspro.next', 'OnAsproRegionalityAddSelectFieldsAndProps', 'OnAsproRegionalityAddSelectFieldsAndPropsHandler'); // regionality
function OnAsproRegionalityAddSelectFieldsAndPropsHandler(&$arSelect){
	if($arSelect)
	{
		// $arSelect[] = 'PROPERTY_TEST';
	}
}*/

/*AddEventHandler('aspro.next', 'OnAsproRegionalityGetElements', 'OnAsproRegionalityGetElementsHandler'); // regionality
function OnAsproRegionalityGetElementsHandler(&$arItems){
	if($arItems)
	{
		print_r($arItems);
		foreach($arItems as $key => $arItem)
		{
			$arItems[$key]['TEST'] = CUSTOM_VALUE;
		}
	}
}*/

// AddEventHandler('aspro.next', 'OnAsproShowPriceMatrix', array('\Aspro\Functions\CAsproNext', 'OnAsproShowPriceMatrixHandler'));
// function - CNext::showPriceMatrix

// AddEventHandler('aspro.next', 'OnAsproShowPriceRangeTop', array('\Aspro\Functions\CAsproNext', 'OnAsproShowPriceRangeTopHandler'));
// function - CNext::showPriceRangeTop

// AddEventHandler('aspro.next', 'OnAsproItemShowItemPrices', array('\Aspro\Functions\CAsproNext', 'OnAsproItemShowItemPricesHandler'));
// function - \Aspro\Functions\CAsproItem::showItemPrices

// AddEventHandler('aspro.next', 'OnAsproSkuShowItemPrices', array('\Aspro\Functions\CAsproNext', 'OnAsproSkuShowItemPricesHandler'));
// function - \Aspro\Functions\CAsproSku::showItemPrices

// AddEventHandler('aspro.next', 'OnAsproGetTotalQuantity', array('\Aspro\Functions\CAsproNext', 'OnAsproGetTotalQuantityHandler'));
// function - CNext::GetTotalCount

// AddEventHandler('aspro.next', 'OnAsproGetTotalQuantityBlock', array('\Aspro\Functions\CAsproNext', 'OnAsproGetTotalQuantityBlockHandler'));
// function - CNext::GetQuantityArray

// AddEventHandler('aspro.next', 'OnAsproGetBuyBlockElement', array('\Aspro\Functions\CAsproNext', 'OnAsproGetBuyBlockElementHandler'));
// function - CNext::GetAddToBasketArray

?>