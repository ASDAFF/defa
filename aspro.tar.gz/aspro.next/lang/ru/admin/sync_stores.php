<?
$MESS['NEXT_PAGE_TITLE'] = 'Синхронизация остатков';
$MESS['NEXT_NO_RIGHTS_FOR_VIEWING'] = 'Доступ закрыт';
$MESS['NEXT_MODULE_NOT_INCLUDED'] = 'Не удалось подключить модуль Аспро: Next';
$MESS['NEXT_MODULE_CONTROL_CENTER_ERROR'] = 'Не удалось получить информацию об установке решения';

$MESS["ASPRO_NEXT_NO_SITE_INSTALLED"] = 'Не найдено сайтов с установленным решением &laquo;Аспро: Next - интернет-магазин&raquo;<br />
<input type="button" value="Установить" style="margin-top: 10px;" onclick="document.location.href=\'/bitrix/admin/wizard_install.php?lang=ru&wizardName=aspro:next&#SESSION_ID#\'">';

$MESS["MAIN_OPTIONS_STORES_TITLE"] = "Общие";
$MESS["NEXT_MODULE_SETTINGS"] = "Настройки";
$MESS["NEXT_MODULE_PARAMS"] = "Параметры";
$MESS["NEXT_MODULE_STORES_INFO"] = "На данной странице будет произведена синхронизация общего наличия товара с наличием на складах, если у вас <b>включен колличественный учет</b> - не устанавливайте опцию синхронизации по событию, иначе будет неверное общее количество у товара";
$MESS["NEXT_MODULE_SYNC_STORES"] = "Синхронизировать";
$MESS["NEXT_MODULE_SAVE"] = "Сохранить настройки";
$MESS["NEXT_MODULE_IBLOCK_ID"] = "ID инфоблока торгового каталога";
$MESS["NEXT_MODULE_IBLOCK_SECTION_ID"] = "ID раздела инфоблока (для увеличения скорости)";
$MESS["NEXT_MODULE_EVENT_SYNC_TITLE"] = "Установить синхронизацию остатков на событии обновления/добавления продукта";
$MESS["NEXT_MODULE_NO_IBLOCK_ID"] = "Не задан ид инфоблока";
$MESS["NEXT_MODULE_NO_CATALOG_IBLOCK_ID"] = "Инфоблок не является торговым каталогом";
$MESS["NEXT_MODULE_NO_CATALOG_CAN_SELECT"] = "Нельзя выбирать инфоблок с торговыми предложениями, элементы данного инфоблока будут автоматически обновлены через привязку к торговому каталогу";
?>