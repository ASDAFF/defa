<?
$MESS['NEXT_CONTROL_CENTER_TITLE'] = 'Центр управления';
$MESS['NEXT_NO_RIGHTS_FOR_VIEWING'] = 'Доступ закрыт';
$MESS['NEXT_MODULE_NOT_INCLUDED'] = 'Не удалось подключить модуль Аспро: Next';
$MESS['NEXT_MODULE_CONTROL_CENTER_ERROR'] = 'Не удалось получить информацию об установке решения';
?>