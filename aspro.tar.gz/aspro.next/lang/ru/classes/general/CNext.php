<?
$MESS["SCOM_BUTTON_NAME"] = "Мастер#BR#настройки";
$MESS["SCOM_BUTTON_DESCRIPTION"] = "Запустить мастер смены дизайна и настроек сайта";
$MESS["STOM_BUTTON_TITLE_W1"] = "Запустить мастер смены дизайна и настройки магазина";
$MESS["STOM_BUTTON_NAME_W1"] = "<b>Мастер настройки магазина</b>";
$MESS["STOM_BUTTON_TITLE_W3"] = "Удаление демонстрационного каталога";
$MESS["STOM_BUTTON_NAME_W3"] = "Удалить демо-каталог";
$MESS["STOM_BUTTON_CONFIRM_W2"] = "Каталог Aspro, установленный в качестве демонстрационного, будет удален. При этом все ваши изменения внутри него будут потеряны. Удалить демо-каталог?";
$MESS["NEXT_MODULE_NOT_INSTALLED"] = 'Модуль &laquo;Аспро: Next - Адаптивный интернет-магазин&raquo; не установлен. Пожалуйста, <a href="/bitrix/admin/partner_modules.php">установите модуль</a> и повторите попытку.';
$MESS["ERROR_INCLUDE_MODULE"] = 'Ошибка подключения модуля';
$MESS["NO_RIGHTS_FOR_VIEWING"] = "Недостаточно прав для просмотра";

$MESS["EXPRESSIONS_OPTIONS"] = "Выражения и названия";
$MESS["BUYNOPRICEGGOODS"] = "Кнопка покупки у товаров с нулевой/отсутствующей ценой";
$MESS["BUYNOPRICEGGOODS_ORDER"] = "Отображать кнопку \"Под заказ\" с попапом";
$MESS["BUYNOPRICEGGOODS_NOTHING"] = "Ничего не отображать";
$MESS["BUYMISSINGGOODS"] = "Кнопка покупки у отсутствующих товаров";
$MESS["BUYMISSINGGOODS_ADD"] = "Отображать кнопку \"В корзину\"";
$MESS["BUYMISSINGGOODS_ORDER"] = "Отображать кнопку \"Под заказ\" с попапом";
$MESS["EXPRESSION_ADDTOBASKET_BUTTON"] = "Название кнопки \"<i>В корзину</i>\"";
$MESS["EXPRESSION_ADDTOBASKET_BUTTON_DEFAULT"] = "В корзину";
$MESS["EXPRESSION_ADDEDTOBASKET_BUTTON_DEFAULT"] = "В корзине";
$MESS["EXPRESSION_SUBSCRIBE_BUTTON"] = "Название кнопки \"<i>Подписаться</i>\"";
$MESS["EXPRESSION_SUBSCRIBE_BUTTON_DEFAULT"] = "Подписаться";
$MESS["EXPRESSION_SUBSCRIBED_BUTTON"] = "Название кнопки \"<i>Отписаться</i>\"";
$MESS["EXPRESSION_SUBSCRIBED_BUTTON_DEFAULT"] = "Отписаться";
$MESS["EXPRESSION_ORDER_BUTTON"] = "Название кнопки \"<i>Под заказ</i>\"";
$MESS["EXPRESSION_ORDER_BUTTON_DEFAULT"] = "Под заказ";
$MESS["EXPRESSION_ORDER_TEXT"] = "Текст под кнопкой \"<i>Под заказ</i>\"";
$MESS["EXPRESSION_ORDER_TEXT_DEFAULT"] = "Наши менеджеры обязательно свяжутся с вами и уточнят условия заказа";
$MESS["EXPRESSION_READ_MORE_OFFERS_DEFAULT"] = "Подробнее";

$MESS["EXPRESSION_FOR_MAX_DEFAULT"] = "Много";
$MESS["EXPRESSION_FOR_MIN_DEFAULT"] = "Мало";
$MESS["EXPRESSION_FOR_MID_DEFAULT"] = "Достаточно";
$MESS["EXPRESSION_FOR_EXISTS_DEFAULT"] = "Есть в наличии";
$MESS["EXPRESSION_FOR_NOTEXISTS_DEFAULT"] = "Нет в наличии";

$MESS["DETAIL"] = "ПОДРОБНОСТИ";
$MESS["ADDRESS"] = "Адрес";
$MESS["PHONE"] = "Телефон";
$MESS["EMAIL"] = "Email";
$MESS["SCHEDULE"] = "Режим работы";
$MESS["METRO"] = "Станция метро";
$MESS["BACK_STORE_LIST"] = "Вернуться";
$MESS["BACK_STORE"] = "Назад";
$MESS["TYPE_SKU"] = "Тип SKU";
$MESS["TYPE_VIEW_FILTER"] = "Умный фильтр";
$MESS["VERTICAL"] = "Вертикальный";
$MESS["HORIZONTAL"] = "Горизонтальный";
$MESS["CT_NAME_GB"] = " гб";
$MESS["CT_NAME_MB"] = " мб";
$MESS["CT_NAME_KB"] = " кб";
$MESS["CT_NAME_b"] = " байт";

$MESS["EMAIL_IS_ALREADY_EXISTS"] = "Email #EMAIL# уже используется";
$MESS["NO_SITE_INSTALLED"] = 'Не найдено сайтов с установленным решением &laquo;Аспро: Next - Адаптивный интернет-магазин&raquo;<br />
<input type="button" value="Установить" style="margin-top: 10px;" onclick="document.location.href=\'/bitrix/admin/wizard_install.php?lang=ru&wizardName=aspro:next&#SESSION_ID#\'">';
$MESS["ONE_CLICK_BUY"] = "Купить в 1 клик";
$MESS["QUICK_ORDER"] = "Быстрый заказ";

$MESS["USER_CABINET2"] = "Личный кабинет";
$MESS["USER_CABINET"] = "Мой кабинет";
$MESS["USER_AUTH"] = "Вход\регистрация";
$MESS["COMPARE_BLOCK"] = "Сравнение товаров";
$MESS["NEXT_T_MENU_CONTACTS_TITLE"] = "Контактная информация";

$MESS["PRICE_MATRIX_COUNT"] = "Количество от #QUANTITY_FROM##QUANTITY_TO#";
$MESS["PRICE_MATRIX_COUNT_TO"] = "до";
$MESS["FAST_VIEW"] = "Быстрый просмотр";
$MESS["TABLES_SIZE_TITLE"] = "Подбор размера";
$MESS["CITY_CHOISE"] = "Выберите город";
$MESS['SUBSCRIBE_ITEM'] = 'Подписка на товар';
$MESS['SUBSCRIBE_ITEM_EMAIL'] = 'Укажите email';
$MESS['SUBSCRIBE_SEND'] = 'Отправить';
$MESS["LOGIN"] = "Войти";
$MESS['NEXT_T_MENU_BACK'] = 'Назад';
$MESS["PRINT_LINK"] = "Версия для печати";
$MESS["AUTHORIZE_TITLE"] = "Личный кабинет";
$MESS["CABINET_LINK2"] = "Личный кабинет";
$MESS["CABINET_LINK"] = "Мой кабинет";
$MESS["JS_BASKET_DELAY_TITLE"] = "Отложенные";
$MESS["JS_BASKET_TITLE"] = "Корзина";
$MESS["JS_COMPARE_TITLE"] = "Сравнение товаров";
$MESS["CALLBACK"] = "Заказать звонок";
$MESS["NEXT_T_MENU_CALLBACK"] = "Телефоны";
$MESS["NEXT_T_MENU_REGIONS"] = "Города";
$MESS["CATALOG_ECONOMY"] = "Экономия";

$MESS["M_SECTIONS_TYPE_VIEW"] = "Шаблон страницы блока списка разделов";
$MESS["M_SECTION_TYPE_VIEW"] = "Шаблон страницы блока списка подразделов";
$MESS["M_SECTION_ELEMENTS_TYPE_VIEW"] = "Шаблон страницы блока списка элементов";
$MESS["M_ELEMENT_TYPE_VIEW"] = "Шаблон страницы блока детальной страницы";
$MESS["M_FROM_MODULE_PARAMS"] = "Из настроек центра управления";

$MESS["PHONE_AUTH_EVENT_NAME_ru"] = "Авторизация на сайте по СМС";
$MESS["PHONE_AUTH_EVENT_DESCRIPTION_ru"] = "#USER_PHONE# - номер телефона\n#CODE# - код авторизации";
$MESS["PHONE_AUTH_EVENT_NAME_en"] = "Authorize using SMS";
$MESS["PHONE_AUTH_EVENT_DESCRIPTION_en"] = "#USER_PHONE# - phone number\n#CODE# - auth code";
$MESS["PHONE_AUTH_TEMPLATE_MESSAGE"] = "Код авторизации #CODE#";
$MESS["PHONE_AUTH_CODE_SENT_ERROR_PHONE_NOT_FINDED"] = "Профиль пользователя не найден";
$MESS["PHONE_AUTH_CODE_SENT_ERROR_NEED_MAIN_UPDATE"] = "Необходимо обновление главного модуля (main) до версии не менее 18.5.0";
$MESS["PHONE_AUTH_CODE_VERIFY_ERROR"] = "Неверный код авторизации из СМС";
$MESS["PHONE_AUTH_ERROR_BAD_CAPTCHA"] = "Неверно введены символы с картинки";
?>