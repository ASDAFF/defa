<?
$MESS["NOT_FOUND_REGION_IBLOCK_ID"] = "Инфоблок с регионом не найден";
$MESS["NOT_FOUND_REGION_ELEMENTS"] = "Инфоблок с регионами пуст";
?>
