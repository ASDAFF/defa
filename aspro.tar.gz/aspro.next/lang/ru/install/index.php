<?
$MESS["PORTAL_WIZARD_NAME"] = "Аспро: Next - интернет-магазин";
$MESS["PORTAL_WIZARD_DESC"] = "Аспро: Next - интернет магазин с поддержкой современных технологий: BigData, композитный сайт, фасетный поиск, адаптивная верстка";
$MESS["ASPRO_NEXT_MOD_INST_OK"] = "Поздравляем, модуль «Аспро: Next - интернет-магазин» успешно установлен!<br />
Для установки готового сайта, пожалуйста перейдите <a href='/bitrix/admin/wizard_list.php?lang=ru'>в список мастеров</a> <br />и выберите пункт «Установить» в меню мастера aspro:next";
$MESS["ASPRO_NEXT_MOD_UNINST_OK"] = "Удаление модуля успешно завершено";
$MESS["ASPRO_NEXT_SCOM_INSTALL_NAME"] = "Аспро: Next - интернет-магазин";
$MESS["ASPRO_NEXT_SCOM_INSTALL_DESCRIPTION"] = "Мастер создания интернет-магазина «Аспро:Next - интернет-магазин»";
$MESS["ASPRO_NEXT_SCOM_INSTALL_TITLE"] = "Установка модуля \"Аспро: Next\"";
$MESS["ASPRO_NEXT_SCOM_UNINSTALL_TITLE"] = "Удаление модуля \"Аспро: Next\"";
$MESS["ASPRO_NEXT_SPER_PARTNER"] = "Аспро";
$MESS["ASPRO_NEXT_PARTNER_URI"] = "http://www.aspro.ru";
$MESS["OPEN_WIZARDS_LIST"] = "Открыть список мастеров";
$MESS["ASPRO_NEXT_INSTALL_SITE"] = "Установить готовый сайт";
?>