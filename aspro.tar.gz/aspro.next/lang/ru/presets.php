<?
$MESS['PRESET_968_TITLE'] = 'Тип 1';
$MESS['PRESET_968_DESCRIPTION'] = 'Значения параметров модуля по умолчанию';
$MESS['PRESET_221_TITLE'] = 'Тип 2';
$MESS['PRESET_221_DESCRIPTION'] = 'Что-то от оптимуса';
$MESS['PRESET_215_TITLE'] = 'Тип 3';
$MESS['PRESET_215_DESCRIPTION'] = 'Светло-зеленый легкий сайт';
$MESS['PRESET_881_TITLE'] = 'Тип 4';
$MESS['PRESET_741_TITLE'] = 'Тип 5';
$MESS['PRESET_889_TITLE'] = 'Тип 6';
