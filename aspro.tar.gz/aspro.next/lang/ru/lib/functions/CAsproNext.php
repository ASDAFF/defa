<?
$MESS['FEW_DAYS_USE'] = 'несколько дней';
$MESS['FEW_WEEKS_USE'] = 'менее месяца';
$MESS['FEW_MONTHS_USE'] = 'несколько месяцев';
$MESS['FEW_YEAR_USE'] = 'более года';
$MESS['POLARITY_1'] = 'Прямая';
$MESS['POLARITY_2'] = 'Обратная';
$MESS['POLARITY_3'] = 'Не определена';
$MESS['PRICES_FROM'] = 'от';
$MESS['S_MORE_BRANDS'] = 'Все производители';
?>